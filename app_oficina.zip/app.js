// Data
const user = {
    name: "Rolha, Pitolha",
    photo: "assets/rolha.png"
};

// Stack contains "Toco" only
const profiles = [
    {
        id: 1,
        name: "Toco, Loco",
        age: 18,
        bio: "Vamo que vamo",
        photos: [
            "assets/toco_1.jpg",
            "assets/toco_2.jpg",
            "assets/toco_3.jpg",
            "assets/toco_4.jpg",
            "assets/toco_5.jpg"
        ]
    }
];

// State
let currentProfileIndex = 0;
let isDragging = false;
let startX = 0;
let currentCard = null;

// DOM Elements
const loginScreen = document.getElementById('login-screen');
const appScreen = document.getElementById('app-screen');
const loginForm = document.getElementById('login-form');
const cardsContainer = document.getElementById('cards-container');
const btnNope = document.getElementById('btn-nope');
const btnLike = document.getElementById('btn-like');
const matchOverlay = document.getElementById('match-overlay');
const matchImgLeft = document.getElementById('match-img-left');
const matchImgRight = document.getElementById('match-img-right');
const matchName = document.getElementById('match-name');
const closeMatchBtn = document.getElementById('close-match');
const keepSwipingBtn = document.getElementById('keep-swiping');

// Init
lucide.createIcons();

// Login Logic (Decoy)
loginForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const btn = loginForm.querySelector('button');
    btn.innerHTML = '<i data-lucide="loader-2" class="animate-spin"></i> Entrando...';
    lucide.createIcons();

    setTimeout(() => {
        loginScreen.classList.add('transition-opacity', 'duration-1000', 'opacity-0');
        setTimeout(() => {
            loginScreen.classList.add('hidden');
            playIntro(); // Start Intro instead of direct render
        }, 1000);
    }, 1500);
});

// Intro Animation Sequence
function playIntro() {
    const introScreen = document.getElementById('intro-screen');
    const introRolha = document.getElementById('intro-rolha');
    const introToco = document.getElementById('intro-toco');
    const introText = document.getElementById('intro-text');

    introScreen.classList.remove('hidden');

    // 1. Rolha is visible for 3 seconds (as requested)
    setTimeout(() => {
        // 2. Animate Split (Rolha Left, Toco Right)
        // Move Rolha Left
        introRolha.classList.remove('scale-125'); // Reset scale
        introRolha.classList.add('-translate-x-[60%]', 'scale-90');

        // Move Toco In from Right
        introToco.classList.remove('translate-x-[200%]', 'opacity-0');
        introToco.classList.add('translate-x-[60%]', 'scale-90');

        // Show VS / Text in middle
        setTimeout(() => {
            introText.classList.remove('opacity-0', 'scale-0');
            introText.classList.add('scale-100');
        }, 500);

        // 3. End Intro & Start Game
        setTimeout(() => {
            introScreen.classList.add('transition-opacity', 'duration-1000', 'opacity-0');
            appScreen.classList.remove('hidden');
            renderCards();

            setTimeout(() => {
                introScreen.classList.add('hidden');
            }, 1000);
        }, 3000); // Wait on split screen for a bit
    }, 3000); // 3 Seconds wait on Rolha solo
}

// Card Rendering
function renderCards() {
    cardsContainer.innerHTML = '';

    // Reverse order so first profile is on top
    const profile = profiles[currentProfileIndex];
    if (!profile) {
        document.getElementById('no-more-cards').classList.remove('hidden');
        return;
    }

    const card = document.createElement('div');
    card.className = 'card cursor-grab active:cursor-grabbing';
    card.style.backgroundImage = `url('${profile.photos[0]}')`;
    card.innerHTML = `
        <div class="card-gradient"></div>
        <div class="card-content">
            <h2 class="text-3xl font-bold flex items-end gap-2">
                ${profile.name} <span class="text-xl font-medium opacity-80">${profile.age}</span>
            </h2>
            <p class="text-gray-200 mt-1 flex items-center gap-1">
                <i data-lucide="map-pin" class="w-4 h-4"></i> Pertinho de você
            </p>
            ${profile.bio ? `<p class="text-gray-300 mt-2 text-sm">${profile.bio}</p>` : ''}
        </div>
    `;

    cardsContainer.appendChild(card);
    currentCard = card;
    lucide.createIcons();
    initSwipe(card);
}

// Swipe Logic (Touch/Mouse)
function initSwipe(card) {
    card.addEventListener('mousedown', startDrag);
    card.addEventListener('touchstart', startDrag, { passive: true });

    document.addEventListener('mousemove', drag);
    document.addEventListener('touchmove', drag, { passive: false });

    document.addEventListener('mouseup', endDrag);
    document.addEventListener('touchend', endDrag);
}

function startDrag(e) {
    isDragging = true;
    startX = e.type.includes('mouse') ? e.clientX : e.touches[0].clientX;
    currentCard.classList.add('swiping');
}

function drag(e) {
    if (!isDragging || !currentCard) return;

    const currentX = e.type.includes('mouse') ? e.clientX : e.touches[0].clientX;
    const deltaX = currentX - startX;

    const rotation = deltaX * 0.1;

    currentCard.style.transform = `translateX(${deltaX}px) rotate(${rotation}deg)`;
}

function endDrag(e) {
    if (!isDragging || !currentCard) return;
    isDragging = false;
    currentCard.classList.remove('swiping');

    const matrix = new WebKitCSSMatrix(window.getComputedStyle(currentCard).transform);
    const translateX = matrix.m41;
    const threshold = window.innerWidth * 0.25;

    if (translateX > threshold) {
        swipe('right');
    } else if (translateX < -threshold) {
        swipe('left');
    } else {
        currentCard.style.transform = 'translate(0px) rotate(0deg)';
    }

    document.removeEventListener('mousemove', drag);
    document.removeEventListener('touchmove', drag);
    document.removeEventListener('mouseup', endDrag);
    document.removeEventListener('touchend', endDrag);
}

function swipe(direction) {
    if (!currentCard) return;

    const x = direction === 'right' ? window.innerWidth * 1.5 : -window.innerWidth * 1.5;
    const rotation = direction === 'right' ? 30 : -30;

    currentCard.style.transition = 'transform 0.5s ease-out';
    currentCard.style.transform = `translateX(${x}px) rotate(${rotation}deg)`;

    setTimeout(() => {
        if (direction === 'right') {
            showMatch(profiles[currentProfileIndex]);
        }

        // Next Card Logic (Loop or Stop)
        // For now, let's just loop "Toco" with different photos maybe? 
        // Or just stop.
        document.getElementById('no-more-cards').classList.remove('hidden');

        // If we wanted to loop the SAME profile indefinitely:
        // renderCards(); 
    }, 300);
}

function showMatch(profile) {
    matchImgLeft.src = user.photo;
    matchImgRight.src = profile.photos[0];

    matchName.innerText = profile.name.split(',')[0];
    matchOverlay.classList.remove('hidden');
    appScreen.classList.add('blur-sm');
}

// Button Listeners
btnNope.addEventListener('click', () => swipe('left'));
btnLike.addEventListener('click', () => swipe('right'));

closeMatchBtn.addEventListener('click', closeMatch);
keepSwipingBtn.addEventListener('click', closeMatch);

function closeMatch() {
    matchOverlay.classList.add('hidden');
    appScreen.classList.remove('blur-sm');
}

// Do not call renderCards(); wait for login.
